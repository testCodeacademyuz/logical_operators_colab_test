from test01 import TaskOne  

q1 = TaskOne("task_1", "homework_1")

def solution(a, b, c):
    return a < b < c

q1.check(solution, "username")