from logical_operators import (
    TaskOne, 
    TaskTwo,
    TaskThree,
    TaskFour,
    TaskFive,
    TaskSix,
    TaskSeven,
    TaskEight,
    TaskNine,
    TaskTen,
    TaskEleven,
    TaskTwelve,
    TaskThirteen,
    TaskFourteen,
    TaskFifteen,
    TaskSixteen,
    TaskSeventeen,
    TaskEighteen,
    TaskNineteen,
    TaskTwenty)

q1 = TaskOne("logic01", "logical_operators")
q2 = TaskTwo("logic02", "logical_operators")
q3 = TaskThree("logic03", "logical_operators")
q4 = TaskFour("logic04", "logical_operators")
q5 = TaskFive("logic05", "logical_operators")
q6 = TaskSix("logic06", "logical_operators")
q7 = TaskSeven("logic07", "logical_operators")
q8 = TaskEight("logic08", "logical_operators")
q9 = TaskNine("logic09", "logical_operators")
q10 = TaskTen("logic10", "logical_operators")
q11 = TaskEleven("logic11", "logical_operators")
q12 = TaskTwelve("logic12", "logical_operators")
q13 = TaskThirteen("logic13", "logical_operators")
q14 = TaskFourteen("logic14", "logical_operators")
q15 = TaskFifteen("logic15", "logical_operators")
q16 = TaskSixteen("logic16", "logical_operators")
q17 = TaskSeventeen("logic17", "logical_operators")
q18 = TaskEighteen("logic18", "logical_operators")
q19 = TaskNineteen("logic19", "logical_operators")
q20 = TaskTwenty("logic20", "logical_operators")