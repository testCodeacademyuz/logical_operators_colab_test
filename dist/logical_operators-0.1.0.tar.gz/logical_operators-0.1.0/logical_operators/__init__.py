from checker import CheckSolution
from test01 import TaskOne