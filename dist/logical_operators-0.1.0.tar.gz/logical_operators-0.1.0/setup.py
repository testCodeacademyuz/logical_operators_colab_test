from setuptools import setup

setup(
   name='logical_operators',
   version='0.1.0',
   packages=['logical_operators'],
   description='This is Logical Operators Test',
   install_requires=[
       "requests",
   ]
)